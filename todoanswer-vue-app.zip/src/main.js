import { createApp } from 'vue'
import App from './AppTodo.vue'

createApp(App).mount('#app')
